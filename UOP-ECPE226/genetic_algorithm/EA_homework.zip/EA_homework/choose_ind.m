function [chosen_ind] = choose_ind(candidate)
    
end